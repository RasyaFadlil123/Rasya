const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');

const axios = require('axios');
const unzipper = require('unzipper');
const TelegramBot = require('node-telegram-bot-api');

const config = require('./config');

if (!config.botToken) {
  console.error('TELEGRAM_BOT_TOKEN belum diisi.');
  process.exit(1);
}

const bot = new TelegramBot(config.botToken, { polling: true });

let activeBuilds = 0;
const queue = [];

async function ensureDir(dirPath) {
  await fsp.mkdir(dirPath, { recursive: true });
}

function nowIso() {
  return new Date().toISOString();
}

function sanitizeName(input) {
  return String(input || 'file')
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/_+/g, '_')
    .slice(0, 120);
}

function isAuthorized(msg) {
  if (config.allowNonOwner) return true;
  const chatId = String(msg.chat.id);
  const userId = String(msg.from?.id || '');
  return config.ownerIds.includes(chatId) || config.ownerIds.includes(userId);
}

async function safeUnzip(zipPath, destDir) {
  await ensureDir(destDir);
  const directory = await unzipper.Open.file(zipPath);

  for (const entry of directory.files) {
    const entryPath = entry.path;
    const normalized = path.normalize(entryPath).replace(/^([.][.][/\\])+/, '');
    if (!normalized || normalized.includes('..') || path.isAbsolute(normalized)) {
      throw new Error(`ZIP mengandung path tidak aman: ${entryPath}`);
    }

    const outputPath = path.join(destDir, normalized);
    const resolved = path.resolve(outputPath);
    const resolvedDest = path.resolve(destDir) + path.sep;

    if (!resolved.startsWith(resolvedDest) && resolved !== path.resolve(destDir)) {
      throw new Error(`ZIP path traversal terdeteksi: ${entryPath}`);
    }

    if (entry.type === 'Directory') {
      await ensureDir(resolved);
      continue;
    }

    await ensureDir(path.dirname(resolved));
    await new Promise((resolve, reject) => {
      entry
        .stream()
        .pipe(fs.createWriteStream(resolved))
        .on('finish', resolve)
        .on('error', reject);
    });
  }
}

async function findFileRecursive(rootDir, matcher, maxDepth = 6, currentDepth = 0) {
  if (currentDepth > maxDepth) return null;

  const entries = await fsp.readdir(rootDir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(rootDir, entry.name);
    if (entry.isFile() && matcher(entry.name, full)) {
      return full;
    }
  }

  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const full = path.join(rootDir, entry.name);
    if (['.git', 'build', '.dart_tool', 'node_modules'].includes(entry.name)) continue;
    const found = await findFileRecursive(full, matcher, maxDepth, currentDepth + 1);
    if (found) return found;
  }

  return null;
}

async function getProjectRoot(extractedDir) {
  const pubspec = await findFileRecursive(
    extractedDir,
    (name) => name === 'pubspec.yaml',
    6,
    0
  );

  if (!pubspec) {
    throw new Error('pubspec.yaml tidak ditemukan. Pastikan ZIP berisi project Flutter yang valid.');
  }

  return path.dirname(pubspec);
}

function buildCommand(mode) {
  const args = ['build', 'apk', '--release'];
  if (mode === 'split') args.push('--split-per-abi');
  return args;
}

function collectApks(projectRoot, mode) {
  const apkBase = path.join(projectRoot, 'build', 'app', 'outputs', 'flutter-apk');
  const expected = mode === 'split'
    ? ['app-armeabi-v7a-release.apk', 'app-arm64-v8a-release.apk', 'app-x86_64-release.apk']
    : ['app-release.apk'];

  const found = expected
    .map((name) => path.join(apkBase, name))
    .filter((file) => fs.existsSync(file));

  if (found.length > 0) return found;

  if (!fs.existsSync(apkBase)) return [];
  return fs.readdirSync(apkBase)
    .filter((name) => name.endsWith('.apk'))
    .map((name) => path.join(apkBase, name));
}

function spawnCommand(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: options.env,
      shell: false
    });

    let stdout = '';
    let stderr = '';
    let killedByTimeout = false;

    const timer = setTimeout(() => {
      killedByTimeout = true;
      child.kill('SIGKILL');
    }, options.timeoutMs || config.buildTimeoutMs);

    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });

    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      if (killedByTimeout) {
        const err = new Error('Proses build melebihi batas waktu dan dihentikan.');
        err.stdout = stdout;
        err.stderr = stderr;
        return reject(err);
      }
      if (code !== 0) {
        const err = new Error(`Perintah gagal dengan exit code ${code}`);
        err.stdout = stdout;
        err.stderr = stderr;
        return reject(err);
      }
      resolve({ stdout, stderr });
    });
  });
}

function buildEnv() {
  const env = { ...process.env };
  if (config.javaHome) env.JAVA_HOME = config.javaHome;
  if (config.androidSdkRoot) {
    env.ANDROID_SDK_ROOT = config.androidSdkRoot;
    env.ANDROID_HOME = config.androidSdkRoot;
  }
  return env;
}

async function writeLog(buildPath, content) {
  const logPath = path.join(buildPath, 'build.log');
  await fsp.writeFile(logPath, content, 'utf8');
  return logPath;
}

async function cleanupDirLater(dirPath, delayMinutes) {
  setTimeout(async () => {
    try {
      await fsp.rm(dirPath, { recursive: true, force: true });
    } catch (err) {
      console.error('Gagal cleanup:', err.message);
    }
  }, delayMinutes * 60 * 1000).unref();
}

async function processBuild(task) {
  const { msg, zipFileId, originalName } = task;
  const buildId = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const buildPath = path.join(config.buildDir, buildId);
  const downloadPath = path.join(buildPath, sanitizeName(originalName || 'project.zip'));
  const extractPath = path.join(buildPath, 'src');

  await ensureDir(config.workRoot);
  await ensureDir(config.downloadDir);
  await ensureDir(config.buildDir);
  await ensureDir(buildPath);

  await bot.sendMessage(msg.chat.id, `Build dimulai.\nID: ${buildId}\nMode APK: ${config.apkMode}`);

  const env = buildEnv();
  let combinedLog = `[${nowIso()}] Build started: ${buildId}${os.EOL}`;

  try {
    const file = await bot.getFile(zipFileId);
    const fileUrl = `https://api.telegram.org/file/bot${config.botToken}/${file.file_path}`;

    const sizeMb = (Number(file.file_size || 0) / (1024 * 1024));
    if (sizeMb > config.maxZipMb) {
      throw new Error(`Ukuran ZIP terlalu besar: ${sizeMb.toFixed(2)} MB. Batas: ${config.maxZipMb} MB.`);
    }

    const response = await axios({
      method: 'GET',
      url: fileUrl,
      responseType: 'stream',
      timeout: 120000,
      maxContentLength: config.maxZipMb * 1024 * 1024,
      maxBodyLength: config.maxZipMb * 1024 * 1024
    });

    await new Promise((resolve, reject) => {
      const writer = fs.createWriteStream(downloadPath);
      response.data.pipe(writer);
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    await safeUnzip(downloadPath, extractPath);
    const projectRoot = await getProjectRoot(extractPath);

    combinedLog += `[${nowIso()}] Project root: ${projectRoot}${os.EOL}`;

    const pubGet = await spawnCommand(config.flutterBin, ['pub', 'get'], {
      cwd: projectRoot,
      env,
      timeoutMs: config.buildTimeoutMs
    });
    combinedLog += `${os.EOL}[flutter pub get][stdout]${os.EOL}${pubGet.stdout}${os.EOL}`;
    combinedLog += `${os.EOL}[flutter pub get][stderr]${os.EOL}${pubGet.stderr}${os.EOL}`;

    const args = buildCommand(config.apkMode);
    const build = await spawnCommand(config.flutterBin, args, {
      cwd: projectRoot,
      env,
      timeoutMs: config.buildTimeoutMs
    });
    combinedLog += `${os.EOL}[flutter ${args.join(' ')}][stdout]${os.EOL}${build.stdout}${os.EOL}`;
    combinedLog += `${os.EOL}[flutter ${args.join(' ')}][stderr]${os.EOL}${build.stderr}${os.EOL}`;

    const apks = collectApks(projectRoot, config.apkMode);
    if (!apks.length) {
      throw new Error('Build selesai tetapi file APK tidak ditemukan.');
    }

    if (config.keepLogs) {
      const logPath = await writeLog(buildPath, combinedLog);
      await bot.sendDocument(msg.chat.id, logPath, {}, {
        filename: `build-${buildId}.log`,
        contentType: 'text/plain'
      });
    }

    for (const apk of apks) {
      await bot.sendDocument(msg.chat.id, apk, {
        caption: `APK berhasil dibuat.\nID: ${buildId}\nFile: ${path.basename(apk)}`
      });
    }

    await bot.sendMessage(msg.chat.id, `Selesai. Total APK: ${apks.length}`);
  } catch (err) {
    const details = [
      `Build gagal.`,
      `ID: ${buildId}`,
      `Error: ${err.message}`
    ].join('\n');

    combinedLog += `${os.EOL}[ERROR] ${err.message}${os.EOL}`;
    if (err.stdout) combinedLog += `${os.EOL}[stdout]${os.EOL}${err.stdout}${os.EOL}`;
    if (err.stderr) combinedLog += `${os.EOL}[stderr]${os.EOL}${err.stderr}${os.EOL}`;

    const logPath = await writeLog(buildPath, combinedLog);
    await bot.sendMessage(msg.chat.id, details);
    await bot.sendDocument(msg.chat.id, logPath, {}, {
      filename: `build-${buildId}-error.log`,
      contentType: 'text/plain'
    });
  } finally {
    cleanupDirLater(buildPath, config.cleanupAfterMinutes);
  }
}

async function runNext() {
  if (activeBuilds >= config.maxConcurrentBuilds) return;
  const next = queue.shift();
  if (!next) return;

  activeBuilds += 1;
  try {
    await processBuild(next);
  } finally {
    activeBuilds -= 1;
    runNext().catch((err) => console.error('Queue error:', err));
  }
}

function enqueueBuild(task) {
  queue.push(task);
  runNext().catch((err) => console.error('Run next error:', err));
  return queue.length + activeBuilds;
}

bot.onText(/^\/start$/, async (msg) => {
  if (!isAuthorized(msg)) {
    await bot.sendMessage(msg.chat.id, 'Akses ditolak.');
    return;
  }

  const text = [
    'Bot builder Flutter APK aktif.',
    '',
    'Cara pakai:',
    '1. Kirim file ZIP project Flutter.',
    '2. Bot akan extract, jalankan flutter pub get, lalu build APK.',
    '3. Hasil APK akan dikirim balik.',
    '',
    `Mode APK saat ini: ${config.apkMode}`,
    `Startup panel: node index.js`
  ].join('\n');

  await bot.sendMessage(msg.chat.id, text);
});

bot.onText(/^\/help$/, async (msg) => {
  if (!isAuthorized(msg)) {
    await bot.sendMessage(msg.chat.id, 'Akses ditolak.');
    return;
  }

  await bot.sendMessage(
    msg.chat.id,
    [
      'Perintah:',
      '/start - status bot',
      '/help - bantuan',
      '/status - status queue',
      '',
      'Kirim dokumen ZIP yang berisi project Flutter.'
    ].join('\n')
  );
});

bot.onText(/^\/status$/, async (msg) => {
  if (!isAuthorized(msg)) {
    await bot.sendMessage(msg.chat.id, 'Akses ditolak.');
    return;
  }

  await bot.sendMessage(
    msg.chat.id,
    `Active builds: ${activeBuilds}\nDalam antrean: ${queue.length}\nMode: ${config.apkMode}`
  );
});

bot.on('document', async (msg) => {
  try {
    if (!isAuthorized(msg)) {
      await bot.sendMessage(msg.chat.id, 'Akses ditolak.');
      return;
    }

    const doc = msg.document;
    if (!doc) return;

    const fileName = doc.file_name || 'project.zip';
    const mimeType = doc.mime_type || '';
    const isZip = fileName.toLowerCase().endsWith('.zip') || mimeType.includes('zip');

    if (!isZip) {
      await bot.sendMessage(msg.chat.id, 'Kirim file ZIP project Flutter.');
      return;
    }

    const sizeMb = (Number(doc.file_size || 0) / (1024 * 1024));
    if (sizeMb > config.maxZipMb) {
      await bot.sendMessage(msg.chat.id, `ZIP terlalu besar. Maksimum ${config.maxZipMb} MB.`);
      return;
    }

    const position = enqueueBuild({
      msg,
      zipFileId: doc.file_id,
      originalName: fileName
    });

    await bot.sendMessage(
      msg.chat.id,
      `File diterima: ${fileName}\nUkuran: ${sizeMb.toFixed(2)} MB\nMasuk antrean. Posisi: ${position}`
    );
  } catch (err) {
    console.error('Document handler error:', err);
    await bot.sendMessage(msg.chat.id, `Terjadi error: ${err.message}`);
  }
});

bot.on('polling_error', (err) => {
  console.error('Polling error:', err.message);
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection:', err);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught exception:', err);
});

(async () => {
  await ensureDir(config.workRoot);
  await ensureDir(config.downloadDir);
  await ensureDir(config.buildDir);
  console.log('Bot aktif. Startup command: node index.js');
})();
