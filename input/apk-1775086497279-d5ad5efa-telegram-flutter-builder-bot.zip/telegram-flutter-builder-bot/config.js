const path = require('path');
require('dotenv').config();

function asBool(value, fallback = false) {
  if (value === undefined || value === null || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
}

function asInt(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function splitIds(value) {
  if (!value) return [];
  return String(value)
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean);
}

const workRoot = process.env.WORK_ROOT || path.join(process.cwd(), 'runtime');

module.exports = {
  botToken: process.env.TELEGRAM_BOT_TOKEN || '',
  ownerIds: splitIds(process.env.OWNER_IDS),
  allowNonOwner: asBool(process.env.ALLOW_NON_OWNER, false),
  workRoot,
  downloadDir: path.join(workRoot, 'downloads'),
  buildDir: path.join(workRoot, 'builds'),
  maxZipMb: asInt(process.env.MAX_ZIP_MB, 100),
  buildTimeoutMs: asInt(process.env.BUILD_TIMEOUT_MS, 25 * 60 * 1000),
  maxConcurrentBuilds: Math.max(1, asInt(process.env.MAX_CONCURRENT_BUILDS, 1)),
  apkMode: ['single', 'split'].includes(process.env.APK_MODE) ? process.env.APK_MODE : 'single',
  flutterBin: process.env.FLUTTER_BIN || 'flutter',
  javaHome: process.env.JAVA_HOME || '',
  androidSdkRoot: process.env.ANDROID_SDK_ROOT || '',
  cleanupAfterMinutes: Math.max(5, asInt(process.env.CLEANUP_AFTER_MINUTES, 30)),
  keepLogs: asBool(process.env.KEEP_LOGS, true)
};
