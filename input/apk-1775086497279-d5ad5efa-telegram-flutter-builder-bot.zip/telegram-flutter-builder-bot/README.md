# Telegram Flutter Builder Bot

Bot Telegram Node.js untuk menerima file ZIP project Flutter, lalu build menjadi APK di server/container.

## File utama
- `index.js`
- `config.js`
- `package.json`
- `.env.example`

## Startup untuk panel
Gunakan startup ini:

```bash
node index.js
```

## Environment
Salin `.env.example` menjadi `.env`, lalu isi:

```env
TELEGRAM_BOT_TOKEN=isi_token_bot
OWNER_IDS=123456789
ALLOW_NON_OWNER=false
WORK_ROOT=/home/container/runtime
MAX_ZIP_MB=100
BUILD_TIMEOUT_MS=1500000
MAX_CONCURRENT_BUILDS=1
APK_MODE=single
FLUTTER_BIN=flutter
JAVA_HOME=
ANDROID_SDK_ROOT=
CLEANUP_AFTER_MINUTES=30
KEEP_LOGS=true
```

## Install lokal
```bash
npm install
node index.js
```

## Fitur
- menerima file ZIP dari Telegram
- validasi hanya file ZIP
- batas ukuran upload
- validasi path saat ekstrak ZIP
- cari `pubspec.yaml`
- jalankan `flutter pub get`
- jalankan `flutter build apk --release`
- mode `split` untuk `--split-per-abi`
- queue build
- timeout build
- kirim log hasil build
- kirim APK kembali ke Telegram
- pembatasan akses owner

## Syarat server
Container harus punya:
- Node.js 18+
- Flutter SDK
- Android SDK
- Java / JDK

## Catatan keamanan
Bot ini lebih aman daripada eksekusi mentah karena:
- tidak memakai shell interpolation dari input user
- membatasi ukuran ZIP
- memblokir path traversal saat ekstrak
- memakai queue dan timeout
- bisa dibatasi hanya owner

Tetapi project Flutter yang dibuild tetap bisa menjalankan proses build Gradle/plugin dari project itu sendiri. Jadi jalankan bot ini di container terisolasi dan jangan simpan secret penting di container builder.
